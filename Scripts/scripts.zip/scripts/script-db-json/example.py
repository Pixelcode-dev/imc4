# example.py - script de demonstração para Script Db Json
def main():
    print("Executando demo para: Script Db Json")

if __name__ == '__main__':
    main()
