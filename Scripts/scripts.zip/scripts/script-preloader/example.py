# example.py - script de demonstração para Script Preloader
def main():
    print("Executando demo para: Script Preloader")

if __name__ == '__main__':
    main()
