# example.py - script de demonstração para Script Api Github Users
def main():
    print("Executando demo para: Script Api Github Users")

if __name__ == '__main__':
    main()
