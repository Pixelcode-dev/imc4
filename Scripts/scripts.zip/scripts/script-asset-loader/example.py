# example.py - script de demonstração para Script Asset Loader
def main():
    print("Executando demo para: Script Asset Loader")

if __name__ == '__main__':
    main()
