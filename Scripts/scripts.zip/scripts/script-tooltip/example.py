# example.py - script de demonstração para Script Tooltip
def main():
    print("Executando demo para: Script Tooltip")

if __name__ == '__main__':
    main()
