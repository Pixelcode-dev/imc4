# example.py - script de demonstração para Script File Manager
def main():
    print("Executando demo para: Script File Manager")

if __name__ == '__main__':
    main()
