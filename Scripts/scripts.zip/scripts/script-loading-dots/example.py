# example.py - script de demonstração para Script Loading Dots
def main():
    print("Executando demo para: Script Loading Dots")

if __name__ == '__main__':
    main()
