# example.py - script de demonstração para Script Cleaner
def main():
    print("Executando demo para: Script Cleaner")

if __name__ == '__main__':
    main()
