# example.py - script de demonstração para Script Ui Interactions
def main():
    print("Executando demo para: Script Ui Interactions")

if __name__ == '__main__':
    main()
