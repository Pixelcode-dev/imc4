# example.py - script de demonstração para Script Open Links
def main():
    print("Executando demo para: Script Open Links")

if __name__ == '__main__':
    main()
