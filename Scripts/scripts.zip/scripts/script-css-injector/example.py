# example.py - script de demonstração para Script Css Injector
def main():
    print("Executando demo para: Script Css Injector")

if __name__ == '__main__':
    main()
