# example.py - script de demonstração para Script Image Loader
def main():
    print("Executando demo para: Script Image Loader")

if __name__ == '__main__':
    main()
