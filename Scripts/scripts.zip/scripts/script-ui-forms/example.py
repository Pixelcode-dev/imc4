# example.py - script de demonstração para Script Ui Forms
def main():
    print("Executando demo para: Script Ui Forms")

if __name__ == '__main__':
    main()
