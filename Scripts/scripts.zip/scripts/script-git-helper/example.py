# example.py - script de demonstração para Script Git Helper
def main():
    print("Executando demo para: Script Git Helper")

if __name__ == '__main__':
    main()
