# example.py - script de demonstração para Script Theme Sync
def main():
    print("Executando demo para: Script Theme Sync")

if __name__ == '__main__':
    main()
