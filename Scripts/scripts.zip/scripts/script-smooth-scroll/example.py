# example.py - script de demonstração para Script Smooth Scroll
def main():
    print("Executando demo para: Script Smooth Scroll")

if __name__ == '__main__':
    main()
