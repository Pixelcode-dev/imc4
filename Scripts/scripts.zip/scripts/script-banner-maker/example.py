# example.py - script de demonstração para Script Banner Maker
def main():
    print("Executando demo para: Script Banner Maker")

if __name__ == '__main__':
    main()
