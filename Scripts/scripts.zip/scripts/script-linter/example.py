# example.py - script de demonstração para Script Linter
def main():
    print("Executando demo para: Script Linter")

if __name__ == '__main__':
    main()
