# example.py - script de demonstração para Script Fetch Projects
def main():
    print("Executando demo para: Script Fetch Projects")

if __name__ == '__main__':
    main()
