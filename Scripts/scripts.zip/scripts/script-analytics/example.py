# example.py - script de demonstração para Script Analytics
def main():
    print("Executando demo para: Script Analytics")

if __name__ == '__main__':
    main()
