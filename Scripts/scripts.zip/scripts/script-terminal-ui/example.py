# example.py - script de demonstração para Script Terminal Ui
def main():
    print("Executando demo para: Script Terminal Ui")

if __name__ == '__main__':
    main()
