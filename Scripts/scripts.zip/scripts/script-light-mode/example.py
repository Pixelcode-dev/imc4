# example.py - script de demonstração para Script Light Mode
def main():
    print("Executando demo para: Script Light Mode")

if __name__ == '__main__':
    main()
