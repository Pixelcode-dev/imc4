# example.py - script de demonstração para Script Theme Preview
def main():
    print("Executando demo para: Script Theme Preview")

if __name__ == '__main__':
    main()
