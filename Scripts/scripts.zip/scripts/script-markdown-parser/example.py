# example.py - script de demonstração para Script Markdown Parser
def main():
    print("Executando demo para: Script Markdown Parser")

if __name__ == '__main__':
    main()
