# example.py - script de demonstração para Script Inspector
def main():
    print("Executando demo para: Script Inspector")

if __name__ == '__main__':
    main()
