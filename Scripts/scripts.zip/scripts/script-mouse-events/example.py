# example.py - script de demonstração para Script Mouse Events
def main():
    print("Executando demo para: Script Mouse Events")

if __name__ == '__main__':
    main()
