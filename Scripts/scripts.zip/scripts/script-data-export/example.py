# example.py - script de demonstração para Script Data Export
def main():
    print("Executando demo para: Script Data Export")

if __name__ == '__main__':
    main()
