# example.py - script de demonstração para Script Dark Mode
def main():
    print("Executando demo para: Script Dark Mode")

if __name__ == '__main__':
    main()
