# example.py - script de demonstração para Script Carousel
def main():
    print("Executando demo para: Script Carousel")

if __name__ == '__main__':
    main()
