# example.py - script de demonstração para Script Api Request
def main():
    print("Executando demo para: Script Api Request")

if __name__ == '__main__':
    main()
