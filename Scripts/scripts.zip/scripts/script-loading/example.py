# example.py - script de demonstração para Script Loading
def main():
    print("Executando demo para: Script Loading")

if __name__ == '__main__':
    main()
