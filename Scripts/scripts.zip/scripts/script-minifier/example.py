# example.py - script de demonstração para Script Minifier
def main():
    print("Executando demo para: Script Minifier")

if __name__ == '__main__':
    main()
