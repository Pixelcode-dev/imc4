# example.py - script de demonstração para Script Theme Switcher
def main():
    print("Executando demo para: Script Theme Switcher")

if __name__ == '__main__':
    main()
