# example.py - script de demonstração para Script Typing Effect
def main():
    print("Executando demo para: Script Typing Effect")

if __name__ == '__main__':
    main()
