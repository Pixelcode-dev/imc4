# example.py - script de demonstração para Script Devtools
def main():
    print("Executando demo para: Script Devtools")

if __name__ == '__main__':
    main()
