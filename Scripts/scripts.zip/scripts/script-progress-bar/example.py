# example.py - script de demonstração para Script Progress Bar
def main():
    print("Executando demo para: Script Progress Bar")

if __name__ == '__main__':
    main()
