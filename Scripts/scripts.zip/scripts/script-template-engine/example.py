# example.py - script de demonstração para Script Template Engine
def main():
    print("Executando demo para: Script Template Engine")

if __name__ == '__main__':
    main()
