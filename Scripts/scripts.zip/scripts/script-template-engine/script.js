// script.js - comportamento de exemplo para Script Template Engine
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Script Template Engine'));
});
