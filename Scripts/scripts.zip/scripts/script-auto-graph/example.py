# example.py - script de demonstração para Script Auto Graph
def main():
    print("Executando demo para: Script Auto Graph")

if __name__ == '__main__':
    main()
