# example.py - script de demonstração para Script Fetch Repos
def main():
    print("Executando demo para: Script Fetch Repos")

if __name__ == '__main__':
    main()
