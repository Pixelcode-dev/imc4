# example.py - script de demonstração para Script Json Reader
def main():
    print("Executando demo para: Script Json Reader")

if __name__ == '__main__':
    main()
