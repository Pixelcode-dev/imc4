# example.py - script de demonstração para Script Debugger
def main():
    print("Executando demo para: Script Debugger")

if __name__ == '__main__':
    main()
