# example.py - script de demonstração para Script Api Github Langs
def main():
    print("Executando demo para: Script Api Github Langs")

if __name__ == '__main__':
    main()
