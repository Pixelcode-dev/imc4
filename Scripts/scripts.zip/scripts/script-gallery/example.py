# example.py - script de demonstração para Script Gallery
def main():
    print("Executando demo para: Script Gallery")

if __name__ == '__main__':
    main()
