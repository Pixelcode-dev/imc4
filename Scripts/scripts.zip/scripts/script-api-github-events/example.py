# example.py - script de demonstração para Script Api Github Events
def main():
    print("Executando demo para: Script Api Github Events")

if __name__ == '__main__':
    main()
