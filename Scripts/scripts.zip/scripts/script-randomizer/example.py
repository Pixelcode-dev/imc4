# example.py - script de demonstração para Script Randomizer
def main():
    print("Executando demo para: Script Randomizer")

if __name__ == '__main__':
    main()
