// script.js - comportamento de exemplo para Script Generator Md
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Script Generator Md'));
});
