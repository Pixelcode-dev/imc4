# example.py - script de demonstração para Script Generator Md
def main():
    print("Executando demo para: Script Generator Md")

if __name__ == '__main__':
    main()
