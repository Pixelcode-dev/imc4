# example.py - script de demonstração para Script Progress Circle
def main():
    print("Executando demo para: Script Progress Circle")

if __name__ == '__main__':
    main()
