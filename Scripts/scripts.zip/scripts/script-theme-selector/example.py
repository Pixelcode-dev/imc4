# example.py - script de demonstração para Script Theme Selector
def main():
    print("Executando demo para: Script Theme Selector")

if __name__ == '__main__':
    main()
