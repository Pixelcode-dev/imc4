# example.py - script de demonstração para Script Colorize
def main():
    print("Executando demo para: Script Colorize")

if __name__ == '__main__':
    main()
