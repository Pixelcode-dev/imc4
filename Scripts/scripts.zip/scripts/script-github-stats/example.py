# example.py - script de demonstração para Script Github Stats
def main():
    print("Executando demo para: Script Github Stats")

if __name__ == '__main__':
    main()
