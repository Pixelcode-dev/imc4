# example.py - script de demonstração para Script Ui Buttons
def main():
    print("Executando demo para: Script Ui Buttons")

if __name__ == '__main__':
    main()
