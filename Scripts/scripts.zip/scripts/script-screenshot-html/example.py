# example.py - script de demonstração para Script Screenshot Html
def main():
    print("Executando demo para: Script Screenshot Html")

if __name__ == '__main__':
    main()
