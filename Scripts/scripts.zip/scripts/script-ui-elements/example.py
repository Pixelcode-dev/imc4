# example.py - script de demonstração para Script Ui Elements
def main():
    print("Executando demo para: Script Ui Elements")

if __name__ == '__main__':
    main()
