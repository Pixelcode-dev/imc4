# example.py - script de demonstração para Script Auto Bio
def main():
    print("Executando demo para: Script Auto Bio")

if __name__ == '__main__':
    main()
