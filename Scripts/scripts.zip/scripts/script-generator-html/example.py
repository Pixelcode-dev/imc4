# example.py - script de demonstração para Script Generator Html
def main():
    print("Executando demo para: Script Generator Html")

if __name__ == '__main__':
    main()
