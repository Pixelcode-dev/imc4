# example.py - script de demonstração para Script Profile Maker
def main():
    print("Executando demo para: Script Profile Maker")

if __name__ == '__main__':
    main()
