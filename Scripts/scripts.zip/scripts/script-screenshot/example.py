# example.py - script de demonstração para Script Screenshot
def main():
    print("Executando demo para: Script Screenshot")

if __name__ == '__main__':
    main()
