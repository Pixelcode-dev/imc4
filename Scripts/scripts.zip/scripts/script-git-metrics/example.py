# example.py - script de demonstração para Script Git Metrics
def main():
    print("Executando demo para: Script Git Metrics")

if __name__ == '__main__':
    main()
