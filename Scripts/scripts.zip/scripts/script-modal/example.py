# example.py - script de demonstração para Script Modal
def main():
    print("Executando demo para: Script Modal")

if __name__ == '__main__':
    main()
