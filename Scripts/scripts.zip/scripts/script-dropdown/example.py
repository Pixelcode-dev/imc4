# example.py - script de demonstração para Script Dropdown
def main():
    print("Executando demo para: Script Dropdown")

if __name__ == '__main__':
    main()
