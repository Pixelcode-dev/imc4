# example.py - script de demonstração para Script Formatter
def main():
    print("Executando demo para: Script Formatter")

if __name__ == '__main__':
    main()
