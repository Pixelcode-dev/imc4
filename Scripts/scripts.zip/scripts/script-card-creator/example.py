# example.py - script de demonstração para Script Card Creator
def main():
    print("Executando demo para: Script Card Creator")

if __name__ == '__main__':
    main()
