# example.py - script de demonstração para Script Img Zoom
def main():
    print("Executando demo para: Script Img Zoom")

if __name__ == '__main__':
    main()
