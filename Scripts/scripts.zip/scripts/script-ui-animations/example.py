# example.py - script de demonstração para Script Ui Animations
def main():
    print("Executando demo para: Script Ui Animations")

if __name__ == '__main__':
    main()
