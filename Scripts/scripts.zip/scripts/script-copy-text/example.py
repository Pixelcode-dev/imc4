# example.py - script de demonstração para Script Copy Text
def main():
    print("Executando demo para: Script Copy Text")

if __name__ == '__main__':
    main()
