# example.py - script de demonstração para Script Json Writer
def main():
    print("Executando demo para: Script Json Writer")

if __name__ == '__main__':
    main()
