# example.py - script de demonstração para Script Color Generator
def main():
    print("Executando demo para: Script Color Generator")

if __name__ == '__main__':
    main()
