# example.py - script de demonstração para Script Typing Speed
def main():
    print("Executando demo para: Script Typing Speed")

if __name__ == '__main__':
    main()
