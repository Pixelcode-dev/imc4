# example.py - script de demonstração para Script Keyboard Events
def main():
    print("Executando demo para: Script Keyboard Events")

if __name__ == '__main__':
    main()
