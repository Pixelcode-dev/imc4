# example.py - script de demonstração para Script Folder Builder
def main():
    print("Executando demo para: Script Folder Builder")

if __name__ == '__main__':
    main()
